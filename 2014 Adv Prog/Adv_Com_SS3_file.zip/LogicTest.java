
public class LogicTest {
 public static void main(String[]args){
	 int x=3;
	 int y=(int)(Math.random()*2);
	 
		 System.out.print(y);
	 
 }
}
